import json
import os
import logging
import boto3
import ipaddress

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Create SNS client and get SNS topic ARN from environment variables
sns_client = boto3.client('sns')
SNS_TOPIC_ARN = os.environ.get("SNS_TOPIC_ARN")

def lambda_handler(event, context):
    """
    Lambda entry point. Expects events triggered by CloudWatch Events (from CloudTrail)
    for IAM, S3, or EC2 security group changes.
    """
    logger.info("Received event: %s", json.dumps(event))
    
    try:
        # Extract common event attributes
        detail = event.get("detail", {})
        event_time = event.get("time", "N/A")
        event_name = detail.get("eventName", "N/A")
        initiator = get_initiator(detail)
        resource_arn = get_resource_arn(detail, event)
        
        message = None  # Message to be published
        
        # Process events based on eventName
        if event_name == "CreateUser":
            message = (
                f"Time: {event_time}\n"
                f"Resource: {resource_arn}\n"
                f"Initiator: {initiator}\n"
                f"Action: IAM User Creation"
            )
        elif event_name == "CreateAccessKey":
            message = (
                f"Time: {event_time}\n"
                f"Resource: {resource_arn}\n"
                f"Initiator: {initiator}\n"
                f"Action: IAM User Creating New Programmatic Access Keys"
            )
        elif event_name == "PutBucketPolicy":
            message = (
                f"Time: {event_time}\n"
                f"Resource: {resource_arn}\n"
                f"Initiator: {initiator}\n"
                f"Action: S3 Bucket Policy Change"
            )
        elif event_name == "AuthorizeSecurityGroupIngress":
            # Only alert if at least one ingress rule is opened to a non-private IP range
            if is_non_private_ingress(detail):
                message = (
                    f"Time: {event_time}\n"
                    f"Resource: {resource_arn}\n"
                    f"Initiator: {initiator}\n"
                    f"Action: Security Group Ingress Rule Change (non-private IP range)"
                )
            else:
                logger.info("Security group ingress change does not include non-private IP ranges. No alert sent.")
        else:
            logger.info("Event '%s' is not configured for alerts.", event_name)
        
        if message:
            # Publish the notification to the SNS topic
            response = sns_client.publish(
                TopicArn=SNS_TOPIC_ARN,
                Message=message,
                Subject=f"Security Alert: {event_name}"
            )
            logger.info("Notification sent successfully. SNS response: %s", json.dumps(response))
        else:
            logger.info("No notification triggered for this event.")
    
    except Exception as e:
        logger.exception("Error processing event: %s", str(e))
        # Optionally re-raise the exception if you want Lambda to mark this as a failed invocation
        raise e

def get_initiator(detail):
    """
    Extract the initiator information from the event detail.
    Typically, this is stored under the 'userIdentity' key.
    """
    user_identity = detail.get("userIdentity", {})
    # Prefer the 'arn' field, but fallback to 'userName' if needed.
    return user_identity.get("arn") or user_identity.get("userName", "N/A")

def get_resource_arn(detail, event):
    """
    Construct a resource ARN based on the event details.
    This function handles different events:
      - For IAM CreateUser, the ARN is typically in responseElements.user.arn.
      - For CreateAccessKey, we construct the ARN from the username.
      - For PutBucketPolicy, we construct an S3 bucket ARN.
      - For AuthorizeSecurityGroupIngress, we construct a security group ARN.
    """
    event_name = detail.get("eventName", "")
    if event_name == "CreateUser":
        return detail.get("responseElements", {}).get("user", {}).get("arn", "N/A")
    elif event_name == "CreateAccessKey":
        # Construct ARN using the username from the access key response.
        access_key_info = detail.get("responseElements", {}).get("accessKey", {})
        username = access_key_info.get("userName")
        if username:
            account_id = event.get("account", "N/A")
            return f"arn:aws:iam::{account_id}:user/{username}"
        else:
            return "N/A"
    elif event_name == "PutBucketPolicy":
        bucket_name = detail.get("requestParameters", {}).get("bucketName")
        if bucket_name:
            return f"arn:aws:s3:::{bucket_name}"
        else:
            return "N/A"
    elif event_name == "AuthorizeSecurityGroupIngress":
        group_id = detail.get("requestParameters", {}).get("groupId")
        if group_id:
            region = event.get("region", "us-east-1")
            account_id = event.get("account", "N/A")
            return f"arn:aws:ec2:{region}:{account_id}:security-group/{group_id}"
        else:
            return "N/A"
    return "N/A"

def is_non_private_ingress(detail):
    """
    Determines whether the security group ingress rule changes include a rule 
    that allows access from a non-private IP range.
    """
    try:
        # Get the ipPermissions structure.
        ip_permissions_raw = detail.get("requestParameters", {}).get("ipPermissions", {})
        
        # Expect ip_permissions_raw to be a dictionary with an "items" key.
        ip_permissions = ip_permissions_raw.get("items", [])
        
        for permission in ip_permissions:
            # If permission is not a dict, log a warning and skip.
            if not isinstance(permission, dict):
                logger.warning("Unexpected permission structure (not a dict): %s", permission)
                continue

            # Expect ipRanges to be a dictionary with an "items" key.
            ip_ranges_raw = permission.get("ipRanges", {})
            ip_ranges = ip_ranges_raw.get("items", [])
            
            for ip_range in ip_ranges:
                # Ensure ip_range is a dict before calling .get()
                if isinstance(ip_range, dict):
                    cidr = ip_range.get("cidrIp")
                    if cidr:
                        try:
                            network = ipaddress.ip_network(cidr)
                        except ValueError:
                            logger.warning("Invalid CIDR format: %s", cidr)
                            continue
                        # If the network is not private, we consider it a non-private ingress rule.
                        if not network.is_private:
                            logger.info("Found non-private CIDR: %s", cidr)
                            return True
                else:
                    logger.warning("Unexpected ip_range structure (not a dict): %s", ip_range)
        return False
    except Exception as e:
        logger.exception("Error checking ingress rule for non-private IPs: %s", str(e))
        # In case of an error, return False so as not to raise a false alarm.
        return False
